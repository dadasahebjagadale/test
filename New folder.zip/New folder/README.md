I need web application using python and FastAPI with following features.
1) Swagger UI for rest api
2) Graphql playground for graphql api
3) Authentication and authorization for both rest and graphql apis
4) In memory database with script for admin user creation
5) Rest and Graphql apis for user crud operation with user role
6) Role based access for each api rest as well graphql
7) separate packages for rest and graphql api's
8) one todo crud example for rest and one customer crud operation for graphql
9) DockerFile to dockerrize


pip install --no-cache-dir -r requirements.txt
python -m app.main
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8080

http://127.0.0.1:8080/docs
http://127.0.0.1:8080/graphql


docker build -t fastapi-app .
docker run -p 80:80 fastapi-app

If you want to create an admin user, run the script:
python scripts/create_admin.py










mutation {
  createTodo(title: "Buy groceries", description: "Milk, Bread, Eggs") {
    id
    title
    description
    completed
    createdAt
    updatedAt
  }
}


query {
  todos {
    id
    title
    description
    completed
    createdAt
    updatedAt
  }
}

query {
  todo(todoId: 1) {
    id
    title
    description
    completed
    createdAt
    updatedAt
  }
}



mutation {
  updateTodo(todoId: 1, title: "Buy groceries and fruits", completed: true) {
    id
    title
    description
    completed
    createdAt
    updatedAt
  }
}


mutation {
  deleteTodo(todoId: 1)
}