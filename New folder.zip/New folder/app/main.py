from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.openapi.utils import get_openapi
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from app.rest import users
from app.graphql.schema import schema
from app.database import create_tables, get_db
from scripts.create_admin import create_admin_user
from app.auth import verify_token, create_access_token, verify_password
from strawberry.fastapi import GraphQLRouter
from app import models
import uvicorn
from app.ssl_utils import get_ssl_context

# Create tables and admin user
create_tables()
create_admin_user()

app = FastAPI(
    title="FastAPI with REST & GraphQL API's",
    docs_url="/swagger-ui",
    openapi_tags=[
        {"name": "Access Token", "description": "Operations related to authentication"},
        {"name": "User Management", "description": "User management endpoints"},
        {"name": "GraphQL", "description": "GraphQL API endpoint"},
    ]
        #dependencies=[Depends(verify_token)]
)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/token")

# Custom OpenAPI schema to include OAuth2 security scheme
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema

    openapi_schema = get_openapi(
        title="FastAPI with REST & GraphQL API's",
        version="1.0",
        #description="API documentation with OAuth2",
        routes=app.routes,
    )

    if "components" not in openapi_schema:
        openapi_schema["components"] = {}
    if "securitySchemes" not in openapi_schema["components"]:
        openapi_schema["components"]["securitySchemes"] = {}

    openapi_schema["components"]["securitySchemes"]["OAuth2PasswordBearer"] = {
        "type": "oauth2",
        "flows": {
            "password": {
                "tokenUrl": "/token",
                "scopes": {
                    "read": "Read access",
                    "write": "Write access",
                },
            }
        },
    }
    openapi_schema["security"] = [{"OAuth2PasswordBearer": []}]

    # Remove the /graphql path from the OpenAPI schema
    if "/graphql" in openapi_schema["paths"]:
        del openapi_schema["paths"]["/graphql"]

    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

@app.post("/token", tags=["Access Token"])
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == form_data.username).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect username or password")
    access_token = create_access_token(data={"sub": user.username})
    return {"access_token": access_token, "token_type": "bearer"}

# Include REST routers
app.include_router(
    users.router,
    prefix="/api",
    dependencies=[Depends(verify_token)],
    tags=["User Management"]
    )

# Custom context function
async def get_context():
    db = next(get_db())
    return {"db": db}


# Add GraphQL endpoint
graphql_app = GraphQLRouter(schema, context_getter=get_context)
app.include_router(
    graphql_app, 
    prefix="/graphql",
    tags=["GraphQL"]
    )

# Middleware for CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add Swagger UI authorization button
app.swagger_ui_init_oauth = {
    "clientId": "your-client-id",
    "appName": "FastAPI App",
    "scopes": "read write",
    "usePkceWithAuthorizationCodeGrant": True
}

# Paths to the certificate and key files
CERT_FILE = "cert.pem"
KEY_FILE = "key.pem"

# Create an SSL context
ssl_context = get_ssl_context(CERT_FILE, KEY_FILE)

if __name__ == "__main__":
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8080,
        ssl_certfile=CERT_FILE,
        ssl_keyfile=KEY_FILE,
        loop="asyncio"
    )