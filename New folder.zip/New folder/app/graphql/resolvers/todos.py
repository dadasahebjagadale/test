from typing import List, Optional
from sqlalchemy.orm import Session
from ...models import Todo
from ...database import get_db
import strawberry

@strawberry.type
class TodoType:
    id: int
    title: str
    description: Optional[str]
    completed: bool
    created_at: str
    updated_at: Optional[str]  # Allow updated_at to be None

def get_todos(db: Session) -> List[TodoType]:
    todos = db.query(Todo).all()
    return [
        TodoType(
            id=todo.id,
            title=todo.title,
            description=todo.description,
            completed=todo.completed,
            created_at=todo.created_at.isoformat(),
            updated_at=todo.updated_at.isoformat() if todo.updated_at else None,  # Handle None
        )
        for todo in todos
    ]

def get_todo(db: Session, todo_id: int) -> Optional[TodoType]:
    todo = db.query(Todo).filter(Todo.id == todo_id).first()
    if todo:
        return TodoType(
            id=todo.id,
            title=todo.title,
            description=todo.description,
            completed=todo.completed,
            created_at=todo.created_at.isoformat(),
            updated_at=todo.updated_at.isoformat() if todo.updated_at else None,  # Handle None
        )
    return None

def create_todo(db: Session, title: str, description: Optional[str] = None) -> TodoType:
    todo = Todo(title=title, description=description)
    db.add(todo)
    db.commit()
    db.refresh(todo)
    return TodoType(
        id=todo.id,
        title=todo.title,
        description=todo.description,
        completed=todo.completed,
        created_at=todo.created_at.isoformat(),
        updated_at=todo.updated_at.isoformat() if todo.updated_at else None,
    )

def update_todo(
    db: Session, todo_id: int, title: Optional[str] = None, description: Optional[str] = None, completed: Optional[bool] = None
) -> Optional[TodoType]:
    todo = db.query(Todo).filter(Todo.id == todo_id).first()
    if not todo:
        return None
    
    if title:
        todo.title = title
    if description:
        todo.description = description
    if completed is not None:
        todo.completed = completed
    
    db.commit()
    db.refresh(todo)
    return TodoType(
        id=todo.id,
        title=todo.title,
        description=todo.description,
        completed=todo.completed,
        created_at=todo.created_at.isoformat(),
        updated_at=todo.updated_at.isoformat(),
    )

def delete_todo(db: Session, todo_id: int) -> bool:
    todo = db.query(Todo).filter(Todo.id == todo_id).first()
    if not todo:
        return False
    
    db.delete(todo)
    db.commit()
    return True