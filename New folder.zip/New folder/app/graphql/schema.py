import strawberry
from typing import List, Optional
from .resolvers.todos import (
    TodoType,
    get_todos,
    get_todo,
    create_todo,
    update_todo,
    delete_todo,
)

# Query Type
@strawberry.type
class Query:
    @strawberry.field
    def get_all_todos(self, info: strawberry.Info) -> List[TodoType]:
        db = info.context["db"]
        return get_todos(db)

    @strawberry.field
    def get_todo_by_id(self, info: strawberry.Info, todo_id: int) -> Optional[TodoType]:
        db = info.context["db"]
        return get_todo(db, todo_id)

# Mutation Type
@strawberry.type
class Mutation:
    @strawberry.mutation
    def create_todo(self, info: strawberry.Info, title: str, description: Optional[str] = None) -> TodoType:
        db = info.context["db"]
        return create_todo(db, title, description)

    @strawberry.mutation
    def update_todo(
        self, info: strawberry.Info, todo_id: int, title: Optional[str] = None, description: Optional[str] = None, completed: Optional[bool] = None
    ) -> Optional[TodoType]:
        db = info.context["db"]
        return update_todo(db, todo_id, title, description, completed)

    @strawberry.mutation
    def delete_todo(self, info: strawberry.Info, todo_id: int) -> bool:
        db = info.context["db"]
        return delete_todo(db, todo_id)

# Schema
schema = strawberry.Schema(query=Query, mutation=Mutation)