package com.hsbc.gc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class EmailAutoSaveTriggerApplication implements CommandLineRunner {

	@Autowired
	private ReadWebPageUtils readWebPageUtils;

	@Autowired
	private SaveOutlookDraftEmailUtils saveOutlookDraftEmailUtils;

	public static void main(String[] args) {
		SpringApplication.run(EmailAutoSaveTriggerApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("readWebPageUtils:"+readWebPageUtils);
		readWebPageUtils.readWebPage();

	}

}
