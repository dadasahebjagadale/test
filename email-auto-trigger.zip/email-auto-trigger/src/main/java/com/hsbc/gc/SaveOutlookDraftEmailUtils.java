package com.hsbc.gc;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

@Component
public class SaveOutlookDraftEmailUtils {

	private Integer exitCode;

	@Autowired
	private ResourceLoader resourceLoader;

	private String getResourceFilePath(String filename) {
		try {
			Resource resource = resourceLoader.getResource("classpath:" + filename);
			String filePath = resource.getFile().getAbsolutePath();
			return filePath;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	private int saveDraftEmail(String subject, String body) {
		try {
			final String scriptPath = getResourceFilePath("createmaildraft.ps1");
			ProcessBuilder pb = new ProcessBuilder("powerShell.exe", "-File", scriptPath, subject, body);
			Process process = pb.start();
			exitCode = process.waitFor();
		} catch (InterruptedException | IOException e) {
			e.printStackTrace();
		}
		return exitCode;
	}
}
