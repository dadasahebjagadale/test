package com.hsbc.gc;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.github.bonigarcia.wdm.WebDriverManager;

@Component
public class ReadWebPageUtils {

	@Value("${rbi_link}")
	private String rbiUrl;
	
	private WebDriver driver;
	
	public ReadWebPageUtils() {
		WebDriverManager.iedriver().setup();
		driver=new InternetExplorerDriver();
	}
	
	public void readWebPage() {
		driver.get(rbiUrl);
        LocalDate today = LocalDate.now().minusDays(1);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM dd, yyyy", Locale.ENGLISH);
        String formattedDate = today.format(formatter);
		WebElement link =driver.findElement(By.xpath("//a[contains(text(), 'Money Market Operations as on " + formattedDate + "'"));
		//link.click();
        // Get the value of the href attribute
        String linkUrl = link.getAttribute("href");
        
        // Print the link URL
        System.out.println("Link URL: " + linkUrl);
	}
	
	
}
